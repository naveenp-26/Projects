import tkinter as tk
import sqlite3
from tkinter import *
from tkinter import messagebox,simpledialog
conn=sqlite3.connect('mydatabse.db')
c=conn.cursor()
c.execute("DROP TABLE IF EXISTS log")
c.execute("CREATE TABLE log(City char(20),Cop_name char(20),Cop_phno int,Branch_name char(20),Area_name char(20),Station_name char(20))")
c.execute("INSERT INTO log VALUES('Trichy','Saravanan',7531598246,'KK nagar','KK nagar busstnd','T-5')")
c.execute("INSERT INTO log VALUES('Trichy','Govind',8246791350,'Srirangam','Ammamandapam rd','T-7')")
c.execute("INSERT INTO log VALUES('Trichy','Ram',4682135795,'Woraiyur','Big sowrasthra rd','T-2')")
c.execute("INSERT INTO log VALUES('Trichy','Laxshman',9825364172,'Palakarai','Sangliyandapuram','T-12')")
c.execute("INSERT INTO log VALUES('Madurai','Venugopal',7531598246,'Southgate','Palace rd','M-5')")
c.execute("INSERT INTO log VALUES('Madurai','Mani',8246791350,'Jaihindpuram','Jaihindpuram 2nd mainrd','M-7')")
c.execute("INSERT INTO log VALUES('Madurai','Padma',4682135795,'Karimedu','Mela ponnagaram','M-2')")
c.execute("INSERT INTO log VALUES('Madurai','Suresh',9825364172,'Subramaniyapuram','Pallivasal N Ln','M-12')")
c.execute("INSERT INTO log VALUES('Coimbatore','Subramani',7531598246,'Annur','184 kovai rd','C-5')")
c.execute("INSERT INTO log VALUES('Coimbatore','Elavalagan',8246791350,'Ukkadam','Palakad mainrd','C-7')")
c.execute("INSERT INTO log VALUES('Coimbatore','Gokul',4682135795,'Selvapuram','Perur main rd','C-2')")
c.execute("INSERT INTO log VALUES('Coimbatore','Bala',9825364172,'Anamalai','95 Greenways rd','C-12')")
c.execute("INSERT INTO log VALUES('Chennai','Mukesh',7531598246,'Adyar','Adyar rd','K-5')")
c.execute("INSERT INTO log VALUES('Chennai','Rudran',8246791350,'Ambattur','Ambattur mainrd','K-7')")
c.execute("INSERT INTO log VALUES('Chennai','Srini',4682135795,'Koyambedu','Koyambedu rd','K-2')")
c.execute("INSERT INTO log VALUES('Chennai','Siva',9825364172,'Ayanavaram','Ayanavaram mainrd','K-12')")
conn.commit()
    
def copfriend():
    
    city=city_input.get()
    city=city.capitalize()
    
    c.execute("SELECT Cop_name,Cop_phno,Branch_name,Area_name,Station_name FROM log WHERE City=?",[city])
    stu=c.fetchall()
    
    for widget in log_frame.winfo_children():
        widget.destroy()

    searched_header=tk.Label(nw,text="Searched city =>",font=("Copperplate Gothic Bold",30,"bold"))
    searched_header.place(relx=0.4,rely=0.2,anchor='center')

    searched_op=tk.Label(nw,text=""+city,font=("Fugaz One",20,"bold"))
    searched_op.place(relx=0.6,rely=0.2,anchor='center')
        
    copname_header=tk.Label(log_frame,text="Cop name",font=("Copperplate Gothic Bold",20,"bold"))
    copname_header.grid(row=0,column=0,padx=10,pady=5)
    
    copno_header=tk.Label(log_frame,text="Cop Phno",font=("Copperplate Gothic Bold",20,"bold"))
    copno_header.grid(row=0,column=1,padx=10,pady=5)
    
    brname_header=tk.Label(log_frame,text="Branch",font=("Copperplate Gothic Bold",20,"bold"))
    brname_header.grid(row=0,column=2,padx=10,pady=5)
    
    arname_header=tk.Label(log_frame,text="Area",font=("Copperplate Gothic Bold",20,"bold"))
    arname_header.grid(row=0,column=3,padx=10,pady=5)
    
    stname_header=tk.Label(log_frame,text="Station",font=("Copperplate Gothic Bold",20,"bold"))
    stname_header.grid(row=0,column=4,padx=10,pady=5)

    for i,cop in enumerate(stu):
        copname_label=tk.Label(log_frame,text=cop[0],font=('calibri',22))
        copname_label.grid(row=i+1,column=0,padx=10,pady=5)

        copno_label=tk.Label(log_frame,text=cop[1],font=('calibri',22))
        copno_label.grid(row=i+1,column=1,padx=10,pady=5)

        brname_label=tk.Label(log_frame,text=cop[2],font=('calibri',22))
        brname_label.grid(row=i+1,column=2,padx=10,pady=5)

        arname_label=tk.Label(log_frame,text=cop[3],font=('calibri',22))
        arname_label.grid(row=i+1,column=3,padx=10,pady=5)

        stname_label=tk.Label(log_frame,text=cop[4],font=('calibri',22))
        stname_label.grid(row=i+1,column=4,padx=10,pady=5)

        log_frame.configure(bd=2,relief='groove')

def nextwin():
    global log_frame
    global nw
    nw=tk.Toplevel(root)
    #nw.attributes('-fullscreen',True)
    nw.geometry("1920x1200")
    nw.title("Your search")
    log_frame=tk.Frame(nw)
    log_frame.place(relx=0.5,rely=0.5,anchor='center')
    copfriend()
    


root=tk.Tk()
#root.attributes('-fullscreen',True)
root.geometry("1920x1200")
root.title("Cop Friendly")
city_label=tk.Label(root,text="Where are you located now ?",font=('Copperplate Gothic Bold',50))
city_label.place(relx=0.5,rely=0.3,anchor='center')

city_input=tk.Entry(root,font=('Cascadia Mono',40))
city_input.place(relx=0.5,rely=0.5,anchor='center')

disp_button=tk.Button(root,text="Search",font=('lemon',25),command=nextwin)
disp_button.place(relx=0.5,rely=0.7,anchor='center')

root.mainloop()

conn.close()
    
